// End-to-end test: spins up the real server and drives a full multi-player game over HTTP + SSE.
const { spawn } = require('child_process');
const assert = require('assert');
const PORT = 4100 + Math.floor(Math.random() * 500), BASE = `http://127.0.0.1:${PORT}`;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const post = async (p, b) => { const r = await fetch(BASE + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) }); return { s: r.status, j: await r.json() }; };

class Client {
  constructor(name) { this.name = name; this.state = null; this.log = []; }
  async open(sess) {
    this.sess = sess; this.ac = new AbortController();
    const q = new URLSearchParams({ code: sess.code, pid: sess.pid, token: sess.token });
    const r = await fetch(BASE + '/api/stream?' + q, { signal: this.ac.signal });
    if (r.status !== 200) throw new Error('stream ' + r.status);
    (async () => { const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      try { for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value); let i;
        while ((i = buf.indexOf('\n\n')) >= 0) { const ev = buf.slice(0, i); buf = buf.slice(i + 2); const m = ev.match(/event: (\w+)\ndata: (.*)/s); if (m && m[1] === 'state') { this.state = JSON.parse(m[2]); this.log.push(this.state.phase); } } } } catch (_) {} })();
    await this.until(s => s);
  }
  close() { this.ac && this.ac.abort(); }
  async until(fn, ms = 4000) { const t = Date.now(); while (Date.now() - t < ms) { if (this.state && fn(this.state)) return this.state; await sleep(25); } throw new Error(this.name + ' timeout; phase=' + (this.state && this.state.phase)); }
  act(type, extra) { return post('/api/action', Object.assign({ code: this.sess.code, pid: this.sess.pid, token: this.sess.token, type }, extra)); }
}

(async () => {
  const srv = spawn('node', ['server.js'], { env: Object.assign({}, process.env, { PORT, DATA_DIR: '/tmp/quiz-test-' + PORT }), stdio: ['ignore', 'pipe', 'inherit'] });
  await new Promise(r => srv.stdout.on('data', d => String(d).includes('Quiz server') && r()));
  let pass = 0; const ok = (c, m) => { assert(c, m); pass++; console.log('  ✓', m); };
  try {
    // --- create / join ---
    const c = await post('/api/create', { name: 'Host' }); ok(c.s === 200 && /^[A-Z]{4}$/.test(c.j.code), 'room created with 4-letter code');
    const code = c.j.code;
    const host = new Client('host'); await host.open(c.j);
    const jb = await post('/api/join', { code, name: 'Bea' }); const jc = await post('/api/join', { code: code.toLowerCase(), name: 'Cy' });
    ok(jb.s === 200 && jc.s === 200, 'two players joined (code is case-insensitive)');
    ok((await post('/api/join', { code, name: 'bea' })).s === 409, 'duplicate name rejected (cannot hijack a seat)');
    ok((await post('/api/join', { code: 'ZZZZ', name: 'X' })).s === 404, 'unknown room rejected');
    const bea = new Client('bea'), cy = new Client('cy'); await bea.open(jb.j); await cy.open(jc.j);
    await host.until(s => s.players.length === 3 && s.players.every(p => p.connected)); ok(true, 'waiting room shows all 3 connected');
    ok(host.state.isHost && !bea.state.isHost, 'only host flagged as host');

    // --- authorisation ---
    ok((await bea.act('start')).s === 403, 'non-host cannot start');
    ok((await bea.act('settings', { count: 3 })).s === 403, 'non-host cannot change settings');
    ok((await post('/api/action', { code, pid: jb.j.pid, token: 'x'.repeat(32), type: 'start' })).s === 401, 'bad token rejected');
    ok((await post('/api/action', { code, pid: jb.j.pid, token: jc.j.token, type: 'submit', answer: 'x' })).s === 401, "cannot act with another player's token");
    ok((await host.act('submit', { answer: 'x' })).s === 409, 'cannot submit before game starts');

    // --- game ---
    await host.act('settings', { count: 3, category: 'ecg', timer: 0 }); await bea.until(s => s.settings.count === 3);
    ok(true, 'settings sync to other players live');
    await host.act('start');
    for (const p of [host, bea, cy]) await p.until(s => s.phase === 'question');
    ok(host.state.q.n === 1 && host.state.q.of === 3 && !JSON.stringify(bea.state).includes('"dx"'), 'all in question 1/3; no answer key sent to players');
    ok(host.state.q.img === bea.state.q.img && bea.state.q.img === cy.state.q.img, 'everyone sees the same image');
    ok((await bea.act('endQuestion')).s === 403, 'non-host cannot end question');

    const answers = { host: 'Atrial fibrillation', bea: 'Sinus rhythm', cy: 'AF' };
    ok((await host.act('submit', { answer: answers.host })).s === 200, 'host submits');
    ok((await host.act('submit', { answer: 'again' })).s === 409, 'duplicate submission blocked');
    await bea.until(s => s.players.find(p => p.isHost).status === 'submitted');
    ok(!JSON.stringify(bea.state).includes(answers.host), "others cannot see host's answer while question is open");
    await bea.act('submit', { answer: answers.bea });
    ok(host.state.phase === 'question', 'waits while a player has not submitted');
    await cy.act('submit', { answer: answers.cy });
    await host.until(s => s.phase === 'judging'); ok(true, 'auto-advances to judging when all submitted');
    ok(host.state.judge && host.state.judge.items.length === 3 && host.state.judge.ref, 'host sees all answers + reference');
    ok(!bea.state.judge && !JSON.stringify(bea.state).includes(answers.cy), 'players do not see answers during judging');
    ok((await bea.act('judge', { target: bea.sess.pid, correct: true })).s === 403, 'player cannot self-judge');
    ok((await host.act('finalize')).s === 409, 'cannot finalize until all judged');
    await host.act('judge', { target: host.sess.pid, correct: true }); await host.act('judge', { target: bea.sess.pid, correct: false }); await host.act('judge', { target: cy.sess.pid, correct: true });
    await host.act('finalize');
    await cy.until(s => s.phase === 'reveal'); ok(cy.state.reveal.dx && cy.state.reveal.items.filter(i => i.ok).length === 2, 'reveal shows diagnosis + verdicts');
    ok(cy.state.players.find(p => p.id === cy.sess.pid).score === 1 && cy.state.players.find(p => p.id === bea.sess.pid).score === 0, 'scores updated (1 / 0)');
    await host.act('next'); await bea.until(s => s.phase === 'question' && s.q.n === 2); ok(true, 'host advances to question 2');

    // --- reconnect + late join mid-question ---
    bea.close(); await host.until(s => !s.players.find(p => p.id === bea.sess.pid).connected); ok(true, 'disconnect shown as offline');
    const late = await post('/api/join', { code, name: 'Dee' }); const dee = new Client('dee'); await dee.open(late.j);
    await dee.until(s => s.phase === 'question' && s.q.n === 2); ok(true, 'late joiner lands in the current question');
    await bea.open(jb.j); await bea.until(s => s.phase === 'question'); ok(bea.state.you === jb.j.pid && bea.state.q.n === 2, 'reconnect restores the same player/question');
    // timeout path: host ends question manually with partial answers
    await host.act('submit', { answer: 'Anterior MI' }); await host.act('endQuestion');
    await host.until(s => s.phase === 'judging'); ok(host.state.judge.items.filter(i => !i.answer).length === 3, 'host can end question; non-submitters flagged');
    await host.act('judge', { target: host.sess.pid, correct: false }); await host.act('finalize');
    await host.until(s => s.phase === 'reveal'); ok(host.state.reveal.items.filter(i => !i.ok).length === 4, 'non-submitters counted incorrect');
    await host.act('next'); await host.until(s => s.q && s.q.n === 3);
    for (const p of [host, bea, cy, dee]) await p.act('submit', { answer: 'Normal sinus rhythm' });
    await host.until(s => s.phase === 'judging');
    for (const p of [host, bea, cy, dee]) await host.act('judge', { target: p.sess.pid, correct: p === cy || p === dee });
    await host.act('finalize'); await host.until(s => s.phase === 'reveal'); await host.act('next');

    // --- final ---
    await bea.until(s => s.phase === 'final'); const b = bea.state.board;
    ok(b[0].rank === 1 && b[0].score >= b[1].score && b.length === 4, 'final leaderboard ranked');
    const scores = Object.fromEntries(b.map(x => [x.name, x.score])); ok(scores.Cy === 2 && scores.Dee === 1 && scores.Host === 1 && scores.Bea === 0, 'final scores correct: ' + JSON.stringify(scores));
    ok(bea.state.review.length === 3, 'review of all questions available');
    ok((await bea.act('playAgain')).s === 403, 'non-host cannot restart');
    const firstSet = bea.state.review.map(r => r.img);
    await host.act('playAgain'); await cy.until(s => s.phase === 'question' && s.q.n === 1);
    ok(cy.state.players.every(p => p.score === 0) && cy.state.players.find(p => p.name === 'Cy').total === 2, 'play again: round scores reset, session totals kept, names kept');
    await host.act('endGame'); await host.until(s => s.phase === 'final'); await host.act('toLobby'); await bea.until(s => s.phase === 'lobby');
    ok(bea.state.players.length === 4, 'back to waiting room keeps all players');
    ok(new Set(firstSet).size === 3, 'questions in a game are unique');

    // --- host handover ---
    await host.act('makeHost', { target: bea.sess.pid }); await cy.until(s => s.hostId === bea.sess.pid); ok(true, 'host can hand over host role');
    ok((await host.act('start')).s === 403, 'old host loses control');
    // --- persistence ---
    const code2 = (await post('/api/create', { name: 'P' })).j.code; ok(!!code2, 'multiple rooms coexist');
    const h = await (await fetch(BASE + '/healthz')).json(); ok(h.rooms === 2 && h.questions > 150, 'health endpoint ok');
    console.log(`\nALL ${pass} CHECKS PASSED`);
  } catch (e) { console.error('\nFAILED:', e.message); process.exitCode = 1; }
  srv.kill(); setTimeout(() => process.exit(process.exitCode || 0), 100);
})();
