const { spawn } = require('child_process'); const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const PORT=4700+Math.floor(Math.random()*200), DIR='/tmp/persist-'+PORT; const B=`http://127.0.0.1:${PORT}`;
const start=()=>new Promise(res=>{const p=spawn('node',['server.js'],{env:{...process.env,PORT,DATA_DIR:DIR},stdio:['ignore','pipe','inherit']});p.stdout.on('data',d=>String(d).includes('Quiz server')&&res(p));});
const post=async(p,b)=>{const r=await fetch(B+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return{s:r.status,j:await r.json()}};
(async()=>{
  let s=await start(); const c=(await post('/api/create',{name:'Host'})).j; const b=(await post('/api/join',{code:c.code,name:'Bea'})).j;
  await post('/api/action',{...c,type:'settings',count:5}); await sleep(700); s.kill('SIGTERM'); await sleep(400);
  s=await start(); const r=await post('/api/join',{code:c.code,pid:b.pid,token:b.token});
  const ac=new AbortController(); const st=await fetch(`${B}/api/stream?code=${c.code}&pid=${c.pid}&token=${c.token}`,{signal:ac.signal});
  const rd=st.body.getReader(); let txt=''; const dec=new TextDecoder(); while(!/event: state\ndata: .*\n\n/s.test(txt)){const {value}=await rd.read(); txt+=dec.decode(value);}
  const S=JSON.parse(txt.match(/data: (.*)/)[1]);
  console.log('restored:',S.players.map(p=>p.name).join(','),'| count =',S.settings.count,'| same player id reconnect:',r.s===200&&r.j.pid===b.pid);
  console.log(S.settings.count===5&&S.players.length===2&&r.j.pid===b.pid?'PERSISTENCE OK':'PERSISTENCE FAIL');
  ac.abort(); s.kill(); process.exit(0);
})();
