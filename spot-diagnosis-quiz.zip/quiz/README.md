# Spot Diagnosis – realtime ECG & X-ray quiz

Multiplayer, full-diagnosis quiz for you and your friends. 163 ECGs + 24 X-rays from your two PDFs.
No database service, no accounts, **no npm install** – it is one Node.js file (`server.js`) plus static files.

## Run locally
```
node server.js          # needs Node 18+
# open http://localhost:3000
```
Others on your Wi-Fi can join at `http://<your-computer-ip>:3000`.

## Put it online (shareable URL) – pick one
**Render (free, easiest, ~3 min)**
1. Put this folder in a GitHub repo (`git init && git add . && git commit -m quiz`, push).
2. render.com → New → *Blueprint* (or *Web Service*) → select the repo. Runtime *Node*, start command `node server.js`, no build command.
3. Open the `https://….onrender.com` URL. Share `…/r/ROOMCODE` with friends.
   Free instances sleep after ~15 min idle (first load takes ~30 s) and lose rooms when they restart – fine for an evening game.

**Fly.io / Railway / any VPS**: a `Dockerfile` and `fly.toml` are included. On Fly: `fly launch --no-deploy`, `fly volumes create quizdata --size 1`, `fly deploy`. The volume keeps rooms alive across restarts. Set `DATA_DIR` to a persistent folder anywhere else.

Environment variables (all optional): `PORT` (default 3000), `DATA_DIR` (where `rooms.json` is saved, default `./data`).

## How it plays
1. Host opens the site → **Create a room** → shares the 4-letter code or the invite link.
2. Everyone appears live in the waiting room. Host picks number of questions, ECG / X-ray / both, timer, and whether the host plays.
3. Everyone sees the same image (zoom, pan, pinch, fullscreen) and submits a full diagnosis. Answers stay hidden until everyone has submitted, the timer ends, or the host ends the question.
4. Host reads each answer, marks ✓/✗ (reference diagnosis shown to the host only), then **Confirm scores**. Reveal shows the diagnosis and scores, then the next image loads automatically after ~7 s.
5. Final podium + leaderboard + review of every image. Host can **Play again** (fresh shuffle, no repeats until the pool is used up; round scores reset, session totals and names stay) or go **Back to the waiting room**.

Robustness: players reconnect automatically (browser stores a private token); reloading restores your seat; late joiners enter at the current question; if the host stays offline for 45 s the longest-present player becomes host; the host can also hand over the role (★) or remove a player (✕). Rooms are saved to disk every change.
Security: all scoring and phase changes happen on the server, every action is token-checked, only the host can start/judge/advance, one submission per player per question, and the answer key is never sent to non-host clients until the reveal.

## Question bank
`data/questions.json` (also `data/answer_key.csv` for easy review). Each item: `{id, type, img, dx}`.
* **ECGs**: diagnoses come straight from the answer panels printed in your PDF. The tracing is cropped away from the answer text.
* **X-rays**: your X-ray PDF contains **no answer key**, so those 24 diagnoses are my reading of the images (`"verified": false`) – the host sees an "AI-suggested key" note. Please review/edit them (edit `dx`, restart). Images I could not diagnose confidently were left out (see `data/answer_key.csv` for what is in).
* Stars, arrows, circles, numbered markers, text labels and green scribbles were removed from the X-rays.

## Tests
`node test/e2e.js` (full multi-player flow, permissions, reconnect, late join, replay) and `node test/persist.js` (restart persistence).
