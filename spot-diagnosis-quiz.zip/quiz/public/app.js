(() => {
'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const app = $('#app'), topRight = $('#topRight');
const LS = { get: k => { try { return localStorage.getItem(k); } catch (_) { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} }, del: k => { try { localStorage.removeItem(k); } catch (_) {} } };

let S = null, es = null, offset = 0, online = false, lastKey = '', draft = '', draftKey = '', errCount = 0;
let session = (() => { try { return JSON.parse(LS.get('miq:session') || 'null'); } catch (_) { return null; } })();
const urlCode = () => { const m = location.pathname.match(/^\/r\/([A-Za-z]{4})/); return m ? m[1].toUpperCase() : ''; };

/* ---------- network ---------- */
async function api(path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || 'Something went wrong'); e.status = r.status; throw e; }
  return j;
}
function toast(msg, bad) { const t = $('#toast'); t.textContent = msg; t.className = 'show' + (bad ? ' err' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => t.className = '', 2800); }
async function act(type, extra) {
  if (!session) return;
  try { await api('/api/action', Object.assign({ code: session.code, pid: session.pid, token: session.token, type }, extra)); }
  catch (e) { toast(e.message, true); }
}
function setSession(s) { session = s; if (s) LS.set('miq:session', JSON.stringify(s)); else LS.del('miq:session'); }

function connect() {
  if (es) es.close();
  if (!session) return;
  const q = new URLSearchParams({ code: session.code, pid: session.pid, token: session.token });
  es = new EventSource('/api/stream?' + q);
  es.addEventListener('state', e => {
    const prev = S; S = JSON.parse(e.data); offset = S.now - Date.now(); errCount = 0; setOnline(true);
    if (prev && prev.phase === 'question' && S.phase === 'question' && S.q.n === prev.q.n) {
      const a = prev.players.filter(p => p.status === 'submitted').length, b = S.players.filter(p => p.status === 'submitted').length;
      if (b > a) beat(1);
    }
    if (location.pathname !== '/r/' + S.code) history.replaceState(null, '', '/r/' + S.code);
    render();
  });
  es.addEventListener('gone', e => { const j = JSON.parse(e.data || '{}'); leaveLocal(j.why === 'kicked' ? 'The host removed you from the room.' : ''); });
  es.onerror = () => { setOnline(false); setTimeout(checkSession, 2500); };
}
async function checkSession() {
  if (!session || online) return;
  try { await api('/api/join', { code: session.code, pid: session.pid, token: session.token }); if (es && es.readyState === 2) connect(); }
  catch (e) { if (e.status === 404 || e.status === 401) leaveLocal('That room is no longer available.'); }
}
function setOnline(v) { online = v; renderTop(); }
function leaveLocal(msg) { if (es) es.close(); es = null; setSession(null); S = null; lastKey = ''; history.replaceState(null, '', '/'); render(); if (msg) toast(msg, true); }

/* ---------- ECG trace in the header ---------- */
const cv = $('#trace'), cx = cv.getContext('2d');
let W = 0, H = 0, buf = [], beatLeft = 0, extra = 0, tick = 0;
const g = (t, c, w, a) => a * Math.exp(-((t - c) ** 2) / (2 * w * w));
const wave = t => g(t, .16, .035, .13) + g(t, .3, .011, -.14) + g(t, .335, .012, 1) + g(t, .37, .012, -.28) + g(t, .62, .06, .3);
const BEAT_N = 64;
function sizeTrace() { const r = cv.getBoundingClientRect(), d = Math.min(2, devicePixelRatio || 1); W = Math.max(60, r.width); H = r.height; cv.width = W * d; cv.height = H * d; cx.setTransform(d, 0, 0, d, 0, 0); buf = new Array(Math.ceil(W)).fill(0); }
function beat(n) { extra += n; }
function frame() {
  if (!document.hidden) {
    tick++;
    if (tick % 1 === 0) {
      let v = (Math.random() - .5) * .02;
      if (beatLeft <= 0 && (extra > 0 || tick % 140 === 0)) { beatLeft = BEAT_N; if (extra > 0) extra--; }
      if (beatLeft > 0) { v += wave((BEAT_N - beatLeft) / BEAT_N); beatLeft--; }
      buf.push(v); buf.shift();
    }
    cx.clearRect(0, 0, W, H);
    cx.lineWidth = 1.8; cx.lineJoin = 'round'; cx.strokeStyle = '#5eead4'; cx.shadowColor = 'rgba(94,234,212,.7)'; cx.shadowBlur = 6;
    cx.beginPath();
    for (let i = 0; i < buf.length; i++) { const y = H * .72 - buf[i] * H * .6; i ? cx.lineTo(i, y) : cx.moveTo(i, y); }
    cx.stroke();
    cx.shadowBlur = 0; const grd = cx.createLinearGradient(0, 0, W * .25, 0); grd.addColorStop(0, 'rgba(10,17,20,1)'); grd.addColorStop(1, 'rgba(10,17,20,0)'); cx.fillStyle = grd; cx.fillRect(0, 0, W * .25, H);
  }
  requestAnimationFrame(frame);
}
sizeTrace(); addEventListener('resize', sizeTrace); requestAnimationFrame(frame);

/* ---------- image viewer (zoom / pan / pinch / fullscreen) ---------- */
const viewers = new Map();
function getViewer(src, type, nocache) {
  const k = src; if (!nocache && viewers.has(k)) return viewers.get(k);
  if (!nocache && viewers.size > 6) viewers.delete(viewers.keys().next().value);
  const el = document.createElement('div'); el.className = 'viewer ' + type; el.tabIndex = 0;
  el.innerHTML = '<div class="loading">Loading image…</div><img alt="" draggable="false"><div class="vtools"><button type="button" data-v="in" aria-label="Zoom in">+</button><button type="button" data-v="out" aria-label="Zoom out">−</button><button type="button" data-v="reset" aria-label="Reset view">⟲</button><button type="button" data-v="fs" aria-label="Fullscreen">⛶</button></div><div class="vhint">Scroll or pinch to zoom, drag to pan, double-tap to zoom</div>';
  const img = el.querySelector('img'); let nw = 0, nh = 0, base = 1, z = 1, tx = 0, ty = 0;
  const pts = new Map(); let last = null;
  const clamp = () => { const w = nw * base * z, h = nh * base * z, VW = el.clientWidth, VH = el.clientHeight; tx = w <= VW ? (VW - w) / 2 : Math.min(0, Math.max(VW - w, tx)); ty = h <= VH ? (VH - h) / 2 : Math.min(0, Math.max(VH - h, ty)); };
  const apply = () => { clamp(); img.style.transform = `translate(${tx}px,${ty}px) scale(${z})`; };
  const autoH = () => { if (el.classList.contains('fs')) { el.style.height = ''; return; } el.style.height = Math.round(Math.max(230, Math.min(innerHeight * .64, el.clientWidth * nh / nw + 2))) + 'px'; };
  const fit = () => { if (!nw) return; autoH(); base = Math.min(el.clientWidth / nw, el.clientHeight / nh); img.style.width = nw * base + 'px'; img.style.height = nh * base + 'px'; z = 1; tx = ty = 0; apply(); };
  const zoomAt = (f, x, y) => { const nz = Math.min(8, Math.max(1, z * f)); const r = nz / z; tx = x - (x - tx) * r; ty = y - (y - ty) * r; z = nz; apply(); };
  img.onload = () => { nw = img.naturalWidth; nh = img.naturalHeight; const l = el.querySelector('.loading'); if (l) l.remove(); fit(); };
  img.src = src;
  new ResizeObserver(() => { if (z === 1) fit(); else apply(); }).observe(el);
  el.addEventListener('wheel', e => { e.preventDefault(); const r = el.getBoundingClientRect(); zoomAt(Math.pow(1.002, -e.deltaY), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
  el.addEventListener('pointerdown', e => { if (e.target.closest('.vtools')) return; el.setPointerCapture(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); el.classList.add('drag'); last = null; });
  el.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId)) return; const p = pts.get(e.pointerId), r = el.getBoundingClientRect();
    if (pts.size === 1) { tx += e.clientX - p.x; ty += e.clientY - p.y; pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); apply(); }
    else if (pts.size === 2) {
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
      if (last) { zoomAt(d / last.d, mx, my); tx += mx - last.mx; ty += my - last.my; apply(); } last = { d, mx, my };
    }
  });
  const up = e => { pts.delete(e.pointerId); last = null; if (!pts.size) el.classList.remove('drag'); };
  el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  el.addEventListener('dblclick', e => { if (e.target.closest('.vtools')) return; const r = el.getBoundingClientRect(); if (z > 1.05) { z = 1; apply(); } else zoomAt(2.6, e.clientX - r.left, e.clientY - r.top); });
  const setFs = on => { el.classList.toggle('fs', on); document.body.style.overflow = on ? 'hidden' : ''; setTimeout(() => (z === 1 ? fit() : apply()), 60); };
  el.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return; const v = b.dataset.v, cxm = el.clientWidth / 2, cym = el.clientHeight / 2;
    if (v === 'in') zoomAt(1.5, cxm, cym); else if (v === 'out') zoomAt(1 / 1.5, cxm, cym); else if (v === 'reset') fit();
    else if (v === 'fs') { if (el.classList.contains('fs')) { if (document.fullscreenElement) document.exitFullscreen(); setFs(false); } else { setFs(true); if (el.requestFullscreen) el.requestFullscreen().catch(() => {}); } }
  });
  document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && el.classList.contains('fs')) setFs(false); });
  el.addEventListener('keydown', e => { if (e.key === 'Escape' && el.classList.contains('fs')) setFs(false); else if (e.key === '+' || e.key === '=') zoomAt(1.4, el.clientWidth / 2, el.clientHeight / 2); else if (e.key === '-') zoomAt(1 / 1.4, el.clientWidth / 2, el.clientHeight / 2); });
  if (!nocache) viewers.set(k, el); return el;
}
function mountViewer() { const slot = $('#vslot'); if (slot && S && S.q) slot.replaceWith(getViewer(S.q.img, S.q.type)); }
function lightbox(src) {
  const o = document.createElement('div'); o.style.cssText = 'position:fixed;inset:0;z-index:150;background:rgba(0,0,0,.88);display:grid;padding:12px';
  const el = getViewer(src, 'xray', true); el.style.height = '100%'; o.appendChild(el); document.body.appendChild(o);
  const x = document.createElement('button'); x.className = 'btn'; x.textContent = 'Close'; x.style.cssText = 'position:absolute;left:18px;top:18px;z-index:5';
  const close = () => { o.remove(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  x.onclick = close; o.appendChild(x); document.addEventListener('keydown', esc_);
}

/* ---------- render ---------- */
function renderTop() {
  if (!session) { topRight.innerHTML = ''; return; }
  topRight.innerHTML = `<span class="conn"><span class="dot ${online ? 'live' : 'warn'}"></span>${online ? 'Live' : 'Reconnecting…'}</span><button class="btn sm ghost" data-act="leave">Leave</button>`;
}
const status = p => {
  if (!p.connected) return '<span class="badge off">offline</span>';
  return { answering: '<span class="badge wait">answering</span>', submitted: '<span class="badge ok">submitted</span>', spectating: '<span class="badge">not playing</span>', pending: '<span class="badge wait">awaiting verdict</span>', judged: '<span class="badge ok">judged</span>', noanswer: '<span class="badge bad">no answer</span>' }[p.status] || '<span class="badge ok">connected</span>';
};
function playerList(withScore) {
  return '<ul class="plist">' + S.players.map(p => `<li class="pl ${p.id === S.you ? 'me' : ''}"><span class="dot ${p.connected ? 'live' : 'off'}"></span><span class="nm">${esc(p.name)}${p.id === S.you ? ' (you)' : ''}</span>${p.isHost ? '<span class="badge host">host</span>' : ''}<span class="sp">${S.phase === 'lobby' ? (p.connected ? '' : '<span class="badge off">offline</span>') : status(p)}${withScore ? `<span class="score">${p.score}</span>` : ''}${S.isHost && p.id !== S.you ? `<button class="btn sm ghost" data-act="makeHost" data-pid="${p.id}" title="Make host">★</button><button class="btn sm ghost danger" data-act="kick" data-pid="${p.id}" title="Remove player">✕</button>` : ''}</span></li>`).join('') + '</ul>';
}
function render() {
  renderTop();
  if (!S) return home();
  const key = S.phase + ':' + (S.q ? S.q.n : 0) + ':' + S.games;
  const same = key === lastKey; lastKey = key;
  const ph = { lobby, question, judging, reveal, final }[S.phase];
  if (S.phase === 'question' && same && $('#qwrap')) return patchQuestion();
  if (!same) window.scrollTo(0, 0);
  ph();
  mountViewer();
}

function home() {
  const code = urlCode(), name = LS.get('miq:name') || '';
  app.innerHTML = `<div class="home"><div class="stack"><h1>Name the diagnosis before your friends do.</h1><p class="mute">Real ECG tracings and X-rays. Everyone sees the same image, types a full diagnosis, and the host marks the answers.</p></div>
  <div class="card stack"><div><label for="nm">Your name</label><input class="input" id="nm" maxlength="20" autocomplete="nickname" value="${esc(name)}" placeholder="e.g. Dr. Salma"></div>
  ${code ? '' : '<button class="btn primary" data-act="create">Create a room</button><div class="or">or join a friend</div>'}
  <div><label for="cd">Room code</label><input class="input code-in" id="cd" maxlength="4" autocapitalize="characters" autocomplete="off" value="${esc(code)}" placeholder="ABCD"></div>
  <button class="btn ${code ? 'primary' : ''}" data-act="join">Join room</button>${code ? '<button class="btn ghost" data-act="create">Create a new room instead</button>' : ''}
  <div id="herr" class="warn-note" role="alert"></div></div></div>`;
  (name && !code ? $('#cd') : $('#nm')).focus();
  $('#cd').addEventListener('input', e => e.target.value = e.target.value.toUpperCase().replace(/[^A-Z]/g, ''));
  app.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') (code || $('#cd').value ? doJoin : doCreate)(); }));
}
async function doCreate() {
  const name = $('#nm').value.trim(); if (!name) return herr('Enter your name first.');
  LS.set('miq:name', name);
  try { setSession(await api('/api/create', { name })); connect(); } catch (e) { herr(e.message); }
}
async function doJoin() {
  const name = $('#nm').value.trim(), code = $('#cd').value.trim().toUpperCase(); if (!name) return herr('Enter your name first.'); if (code.length !== 4) return herr('Room codes have 4 letters.');
  LS.set('miq:name', name);
  try { setSession(await api('/api/join', { code, name })); connect(); } catch (e) { herr(e.message); }
}
const herr = m => { const e = $('#herr'); if (e) e.textContent = m; };

function lobby() {
  const s = S.settings, h = S.isHost, maxN = s.category === 'ecg' ? S.pool.ecg : s.category === 'xray' ? S.pool.xray : S.pool.ecg + S.pool.xray;
  const chips = (k, vals, cur, fmt) => `<div class="chips">${vals.map(v => `<button class="chip" ${h ? `data-act="set" data-k="${k}" data-v="${v}"` : 'disabled'} aria-pressed="${String(cur) === String(v)}">${fmt ? fmt(v) : v}</button>`).join('')}</div>`;
  const link = location.origin + '/r/' + S.code;
  app.innerHTML = `<div class="lobby-grid">
  <section class="card stack"><div><h2>Waiting room</h2><p class="mute small" style="margin:4px 0 0">Share the code or the link. People can join until the game ends.</p></div>
    <div class="code-box"><div class="code" aria-label="Room code ${S.code.split('').join(' ')}">${S.code}</div></div>
    <div class="row"><button class="btn" data-act="copy" data-v="${esc(link)}">Copy invite link</button>${navigator.share ? `<button class="btn" data-act="share" data-v="${esc(link)}">Share…</button>` : ''}</div>
    <h3>Players (${S.players.length})</h3>${playerList(S.games > 0)}</section>
  <section class="card stack"><h2>${h ? 'Game settings' : 'Game settings (host controls these)'}</h2>
    <div><label>Number of questions</label>${chips('count', [5, 10, 15, 20, 30, 40], s.count)}</div>
    <div><label>Image types</label>${chips('category', ['mix', 'ecg', 'xray'], s.category, v => ({ mix: 'ECG + X-ray', ecg: 'ECG only', xray: 'X-ray only' }[v]))}</div>
    <div><label>Time per question</label>${chips('timer', [0, 45, 60, 90, 120, 180], s.timer, v => v ? v + ' s' : 'No limit')}</div>
    <label class="switch"><input type="checkbox" ${h ? '' : 'disabled'} ${s.hostPlays ? 'checked' : ''} data-act="hostPlays"> <span>Host plays too (the host judges all answers, including their own)</span></label>
    <p class="mute small" style="margin:0">${Math.min(s.count, maxN)} questions will be drawn from ${maxN} available ${s.category === 'ecg' ? 'ECGs' : s.category === 'xray' ? 'X-rays' : 'images'}, reshuffled each game.</p>
    ${h ? `<button class="btn primary" data-act="start">Start game</button>` : '<div class="banner">Waiting for the host to start…</div>'}
  </section></div>`;
}

function qHeader() {
  const q = S.q; return `<div class="qhead"><div class="qtag">Question ${q.n} of ${q.of}</div><div class="grow"><div class="prog" role="progressbar" aria-valuemin="1" aria-valuemax="${q.of}" aria-valuenow="${q.n}"><i style="width:${(q.n - (S.phase === 'question' ? 1 : 0.5)) / q.of * 100}%"></i></div></div><div class="timer ${S.deadline ? '' : 'hide'}" id="timer"></div></div>${S.deadline ? '<div class="tbar" id="tbar"><i style="width:100%"></i></div>' : ''}`;
}
function question() {
  const q = S.q, h = S.isHost;
  const key = S.code + ':' + S.games + ':' + q.n; if (draftKey !== key) { draft = ''; draftKey = key; }
  const prompt = q.type === 'ecg' ? 'Give your full diagnosis for this ECG (rhythm, conduction, and any ischemia/infarction or hypertrophy).' : 'Give your full diagnosis for this X-ray.';
  app.innerHTML = `<div id="qwrap">${qHeader()}<div class="grid2"><div><div id="vslot"></div></div>
  <div class="stack"><section class="card stack" id="ansbox"></section><section class="card stack"><div class="row"><h3 class="grow">Players</h3><span class="small mute" id="subcount"></span></div><div id="pl"></div>
  ${h ? '<button class="btn danger" data-act="endQuestion">End question now</button>' : ''}</section></div></div></div>`;
  patchQuestion(true, prompt);
}
function patchQuestion(first, prompt) {
  const q = S.q; prompt = prompt || (q.type === 'ecg' ? 'Give your full diagnosis for this ECG (rhythm, conduction, and any ischemia/infarction or hypertrophy).' : 'Give your full diagnosis for this X-ray.');
  const box = $('#ansbox'), act_ = S.players.filter(p => p.plays), done = act_.filter(p => p.status === 'submitted').length;
  $('#pl').innerHTML = playerList(false); $('#subcount').textContent = `${done} of ${act_.length} submitted`;
  const mine = S.myAnswer;
  if (!S.plays) { box.innerHTML = '<h3>You are hosting</h3><p class="mute">You are not playing this game. When everyone has answered (or time runs out) you will judge the answers.</p>'; return; }
  if (mine) { box.innerHTML = `<h3>Answer locked in</h3><div class="ans">${esc(mine)}</div><p class="mute small" style="margin:0">${done < act_.length ? 'Waiting for the others…' : 'Everyone is in.'}</p>`; return; }
  if (!$('#ans')) {
    box.innerHTML = `<label for="ans" style="color:var(--text);font-size:1rem">${esc(prompt)}</label><textarea id="ans" maxlength="400" placeholder="Type your diagnosis…" autocomplete="off" autocapitalize="sentences" spellcheck="false"></textarea><div class="row"><button class="btn primary grow" data-act="submit">Submit answer</button></div><p class="mute small" style="margin:0">One submission only. Ctrl/Cmd + Enter also submits.</p>`;
    const ta = $('#ans'); ta.value = draft; ta.addEventListener('input', () => draft = ta.value); ta.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submit(); });
    if (first && matchMedia('(min-width:900px)').matches) ta.focus();
  }
}
async function submit() { const ta = $('#ans'); if (!ta) return; const v = ta.value.trim(); if (!v) return toast('Type a diagnosis first.', true); const b = app.querySelector('[data-act=submit]'); if (b) b.disabled = true; await act('submit', { answer: v }); if (b) b.disabled = false; }

function judging() {
  const h = S.isHost, q = S.q;
  let side;
  if (h) {
    const j = S.judge, pend = j.items.filter(i => i.answer && i.verdict === null).length;
    side = `<section class="card stack"><h2>Judge the answers</h2>
      <div class="ref"><div class="small mute">Reference diagnosis</div><b>${esc(j.ref)}</b>${j.verified ? '' : '<div class="warn-note" style="margin-top:6px">AI-suggested key for this X-ray – use your own judgment.</div>'}</div>
      ${j.items.map(i => `<div class="jrow ${i.verdict === true ? 'good' : i.verdict === false ? 'bad' : ''}"><div class="row"><b class="grow">${esc(i.name)}</b>${i.answer ? '' : '<span class="badge bad">no answer</span>'}</div>
        <div class="ans ${i.answer ? '' : 'none'}">${i.answer ? esc(i.answer) : 'Did not submit – counted incorrect'}</div>
        ${i.answer ? `<div class="vbtns"><button class="vbtn yes" data-act="judge" data-pid="${i.id}" data-c="1" aria-pressed="${i.verdict === true}">✓ Correct</button><button class="vbtn no" data-act="judge" data-pid="${i.id}" data-c="0" aria-pressed="${i.verdict === false}">✗ Incorrect</button></div>` : ''}</div>`).join('')}
      <button class="btn primary" data-act="finalize" ${pend ? 'disabled' : ''}>${pend ? `${pend} still to judge` : 'Confirm scores and continue'}</button></section>`;
  } else side = `<section class="card stack"><h2>The host is judging</h2><p class="mute">Answers are in. Scores update as soon as the host confirms.</p>${playerList(false)}</section>`;
  app.innerHTML = `${qHeader()}<div class="grid2"><div><div id="vslot"></div></div><div class="stack">${side}</div></div>`;
}

function reveal() {
  const r = S.reveal, me = r.items.find(i => i.id === S.you);
  app.innerHTML = `${qHeader()}<div class="grid2"><div><div id="vslot"></div></div><div class="stack">
  <section class="card stack"><div class="small mute">Diagnosis</div><div class="rv-dx">${esc(r.dx)}</div>${r.verified ? '' : '<div class="warn-note">Key suggested by AI for this X-ray.</div>'}
  <div class="stack" style="gap:8px">${r.items.map(i => `<div class="pl"><span class="nm" style="white-space:normal">${esc(i.name)}</span><span class="sp"><span class="ans ${i.answer ? '' : 'none'} small" style="max-width:34ch;text-align:right">${i.answer ? esc(i.answer) : 'no answer'}</span><span class="badge ${i.ok ? 'ok' : 'bad'}">${i.ok ? 'correct' : 'incorrect'}</span><span class="score plus ${i.ok ? 'pop' : ''}">${i.score}</span></span></div>`).join('')}</div></section>
  <div class="cd"><i id="cdbar" style="width:100%"></i></div>
  ${S.isHost ? `<div class="row"><button class="btn primary grow" data-act="next">${S.q.n === S.q.of ? 'Show final results' : 'Next question now'}</button><button class="btn danger" data-act="endGame">End game</button></div>` : '<p class="mute small center" style="margin:0">Next image coming up…</p>'}</div></div>`;
}

function final() {
  const b = S.board, top = b.slice(0, 3), order = top.length === 3 ? [top[1], top[0], top[2]] : top.length === 2 ? [top[1], top[0]] : top;
  app.innerHTML = `<div class="stack"><div class="center"><h1>Final scores</h1><p class="mute">${S.review.length} questions played</p></div>
  <section class="card"><div class="podium">${order.map(p => `<div class="pod r${p.rank > 3 ? 3 : p.rank}"><div class="pn">${esc(p.name)}</div><div class="big">${p.score}</div><div class="small mute">#${p.rank}</div></div>`).join('')}</div>
  <table class="tbl"><thead><tr><th>Rank</th><th>Player</th><th class="n">This game</th><th class="n">Session total</th><th class="n">Wins</th></tr></thead><tbody>${b.map(p => `<tr class="${p.id === S.you ? 'me' : ''}"><td>${p.rank}</td><td>${esc(p.name)}</td><td class="n">${p.score}</td><td class="n">${p.total}</td><td class="n">${p.wins}</td></tr>`).join('')}</tbody></table></section>
  ${S.isHost ? '<div class="row"><button class="btn primary grow" data-act="playAgain">Play again (new shuffle)</button><button class="btn grow" data-act="toLobby">Back to waiting room</button></div>' : '<div class="banner">The host can start another round or go back to the waiting room.</div>'}
  <section class="stack"><h2>Review</h2><div class="rev">${S.review.map(r => `<div class="it"><img src="${r.img}" alt="Question ${r.n}" loading="lazy" data-act="zoom" data-src="${r.img}"><div class="tx"><div class="small mute">Question ${r.n}</div><b>${esc(r.dx)}</b>${r.mine ? `<div class="small ${r.mine.ok ? '' : 'mute'}"><span class="badge ${r.mine.ok ? 'ok' : 'bad'}">${r.mine.ok ? 'you got it' : 'missed'}</span> ${esc(r.mine.answer || 'no answer')}</div>` : ''}</div></div>`).join('')}</div></section></div>`;
}

/* ---------- ticking timers ---------- */
setInterval(() => {
  if (!S) return; const t = Date.now() + offset;
  if (S.phase === 'question' && S.deadline) {
    const left = Math.max(0, (S.deadline - t) / 1000), tm = $('#timer'), tb = $('#tbar');
    if (tm) { tm.textContent = Math.ceil(left) + 's'; tm.classList.toggle('low', left <= 10); }
    if (tb) { tb.firstChild.style.width = (left / S.settings.timer * 100) + '%'; tb.classList.toggle('low', left <= 10); }
  }
  if (S.phase === 'reveal') { const bar = $('#cdbar'); if (bar) bar.style.width = Math.max(0, (S.revealUntil - t) / 7000 * 100) + '%'; }
}, 200);

/* ---------- events ---------- */
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]'); if (!el || el.tagName === 'INPUT') return; const a = el.dataset.act;
  if (a === 'create') return doCreate();
  if (a === 'join') return doJoin();
  if (a === 'leave') { if (confirm('Leave this room?')) { await act('leave'); leaveLocal(); } return; }
  if (a === 'copy') { try { await navigator.clipboard.writeText(el.dataset.v); toast('Invite link copied'); } catch (_) { prompt('Copy this link', el.dataset.v); } return; }
  if (a === 'share') { try { await navigator.share({ title: 'Spot Diagnosis', text: 'Join my ECG & X-ray quiz room ' + S.code, url: el.dataset.v }); } catch (_) {} return; }
  if (a === 'set') return act('settings', { [el.dataset.k]: el.dataset.v });
  if (a === 'submit') return submit();
  if (a === 'judge') return act('judge', { target: el.dataset.pid, correct: el.dataset.c === '1' });
  if (a === 'kick') { if (confirm('Remove this player?')) act('kick', { target: el.dataset.pid }); return; }
  if (a === 'makeHost') { if (confirm('Make this player the host?')) act('makeHost', { target: el.dataset.pid }); return; }
  if (a === 'zoom') return lightbox(el.dataset.src);
  if (a === 'endGame') { if (confirm('End the game now?')) act('endGame'); return; }
  act(a);
});
document.addEventListener('change', e => { if (e.target.dataset && e.target.dataset.act === 'hostPlays') act('settings', { hostPlays: e.target.checked }); });
document.addEventListener('visibilitychange', () => { if (!document.hidden && session && (!es || es.readyState === 2)) connect(); });
addEventListener('online', () => session && connect());

if (session && urlCode() && session.code !== urlCode()) { /* opened a different room's link: show the join form, keep old session until a new join succeeds */ session = null; }
if (session) { renderTop(); connect(); app.innerHTML = '<p class="mute center" style="margin-top:20vh">Reconnecting to your room…</p>'; } else render();
})();
