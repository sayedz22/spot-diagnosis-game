'use strict';
/**
 * Medical Image Quiz – realtime multiplayer server.
 * Zero npm dependencies. Node >= 18.
 * Transport: HTTP POST for actions, Server-Sent Events (SSE) for live state.
 * The server is the single source of truth: answers/answer-key never leave the
 * server until the game phase allows it, and only the host can drive the game.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC = path.join(__dirname, 'public');
const QUESTIONS = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'questions.json'), 'utf8'));
const QBY = Object.fromEntries(QUESTIONS.map(q => [q.id, q]));
const POOL = { ecg: QUESTIONS.filter(q => q.type === 'ecg').map(q => q.id), xray: QUESTIONS.filter(q => q.type === 'xray').map(q => q.id) };

const REVEAL_MS = 7000;
const HOST_GRACE_MS = 45000;
const ROOM_TTL_MS = 24 * 3600 * 1000;
const MAX_PLAYERS = 30, MAX_ROOMS = 500, MAX_ANSWER = 400, MAX_NAME = 20;
const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ';

/** @type {Map<string, any>} */
const rooms = new Map();
const conns = new Map(); // code -> Set<{res,pid}>
const timers = new Map(); // code -> timeout

const now = () => Date.now();
const rid = n => crypto.randomBytes(n).toString('hex');
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);

/* ---------- persistence ---------- */
let saveT = null;
function save() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = path.join(DATA_DIR, 'rooms.json.tmp');
      fs.writeFileSync(tmp, JSON.stringify([...rooms.values()]));
      fs.renameSync(tmp, path.join(DATA_DIR, 'rooms.json'));
    } catch (e) { console.error('save failed', e.message); }
  }, 400);
}
function load() {
  try {
    const arr = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'rooms.json'), 'utf8'));
    for (const r of arr) { if (now() - r.updated < ROOM_TTL_MS) { rooms.set(r.code, r); r.players.forEach(p => { p.connected = false; p.lastSeen = now(); }); schedule(r); } }
    console.log('restored', rooms.size, 'rooms');
  } catch (_) { /* first run */ }
}

/* ---------- room helpers ---------- */
function newCode() { for (;;) { let c = ''; for (let i = 0; i < 4; i++) c += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]; if (!rooms.has(c)) return c; } }
function mkPlayer(name) { return { id: rid(4), token: rid(16), name, connected: false, lastSeen: now(), joined: now(), score: 0, total: 0, wins: 0, plays: true, answer: null, verdict: null }; }
function createRoom(name) {
  const code = newCode(); const host = mkPlayer(name);
  const room = { code, created: now(), updated: now(), hostId: host.id, phase: 'lobby', players: [host], settings: { count: 10, category: 'mix', timer: 90, hostPlays: true },
    deck: [], qIndex: 0, deadline: 0, revealUntil: 0, used: [], history: [], games: 0 };
  rooms.set(code, room); save(); return { room, player: host };
}
const getP = (room, id) => room.players.find(p => p.id === id);
const isConn = (code, pid) => { const s = conns.get(code); return !!s && [...s].some(c => c.pid === pid); };
const active = room => room.players.filter(p => p.plays);
const touch = room => { room.updated = now(); save(); };

function buildDeck(room) {
  const { count, category } = room.settings;
  const pick = (type, n) => {
    let avail = POOL[type].filter(id => !room.used.includes(id));
    if (avail.length < n) { room.used = room.used.filter(id => !POOL[type].includes(id)); avail = POOL[type].slice(); }
    return shuffle(avail).slice(0, n);
  };
  let ids;
  if (category === 'ecg') ids = pick('ecg', Math.min(count, POOL.ecg.length));
  else if (category === 'xray') ids = pick('xray', Math.min(count, POOL.xray.length));
  else { const nx = Math.min(Math.round(count / 2), POOL.xray.length); ids = pick('xray', nx).concat(pick('ecg', Math.min(count - nx, POOL.ecg.length))); }
  ids = shuffle(ids); room.used.push(...ids); return ids;
}

/* ---------- state machine ---------- */
function startGame(room) {
  room.players.forEach(p => { p.score = 0; p.answer = null; p.verdict = null; p.plays = (p.id === room.hostId) ? room.settings.hostPlays : true; });
  room.deck = buildDeck(room); room.qIndex = 0; room.history = []; room.games++;
  beginQuestion(room);
}
function beginQuestion(room) {
  room.phase = 'question';
  room.players.forEach(p => { p.answer = null; p.verdict = null; });
  room.deadline = room.settings.timer ? now() + room.settings.timer * 1000 : 0;
  touch(room); schedule(room); broadcast(room);
}
function toJudging(room) {
  if (room.phase !== 'question') return;
  room.phase = 'judging'; room.deadline = 0;
  // players who did not answer are automatically wrong
  active(room).forEach(p => { if (!p.answer) p.verdict = false; });
  touch(room); schedule(room);
  if (!pendingJudge(room).length) return finalize(room);
  broadcast(room);
}
const pendingJudge = room => active(room).filter(p => p.answer && p.verdict === null);
function finalize(room) {
  if (room.phase !== 'judging') return;
  const q = QBY[room.deck[room.qIndex]];
  const res = {};
  active(room).forEach(p => { const ok = p.verdict === true; if (ok) { p.score++; p.total++; } res[p.id] = { answer: p.answer, ok }; });
  room.history.push({ id: q.id, res });
  room.phase = 'reveal'; room.revealUntil = now() + REVEAL_MS;
  touch(room); schedule(room); broadcast(room);
}
function nextQuestion(room) {
  if (room.phase !== 'reveal') return;
  room.qIndex++;
  if (room.qIndex >= room.deck.length) return endGame(room);
  beginQuestion(room);
}
function endGame(room) {
  room.phase = 'final';
  const top = Math.max(0, ...active(room).map(p => p.score));
  if (top > 0) active(room).filter(p => p.score === top).forEach(p => p.wins++);
  touch(room); schedule(room); broadcast(room);
}
function toLobby(room) {
  room.phase = 'lobby'; room.deck = []; room.qIndex = 0; room.history = [];
  room.players.forEach(p => { p.score = 0; p.answer = null; p.verdict = null; p.plays = true; });
  touch(room); schedule(room); broadcast(room);
}
function checkAllIn(room) {
  if (room.phase !== 'question') return;
  const need = active(room).filter(p => isConn(room.code, p.id));
  if (need.length && need.every(p => p.answer)) toJudging(room);
}
function schedule(room) {
  clearTimeout(timers.get(room.code)); timers.delete(room.code);
  let at = 0, fn = null;
  if (room.phase === 'question' && room.deadline) { at = room.deadline; fn = () => toJudging(room); }
  else if (room.phase === 'reveal') { at = room.revealUntil; fn = () => nextQuestion(room); }
  if (!fn) return;
  const t = setTimeout(() => { try { fn(); } catch (e) { console.error(e); } }, Math.max(0, at - now()) + 30);
  timers.set(room.code, t);
}

/* ---------- views (what each client may see) ---------- */
function rank(room) {
  const list = active(room).map(p => ({ id: p.id, name: p.name, score: p.score, total: p.total, wins: p.wins })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  let r = 0, prev = null, i = 0;
  list.forEach(x => { i++; if (x.score !== prev) { r = i; prev = x.score; } x.rank = r; });
  return list;
}
function view(room, me) {
  const host = me.id === room.hostId;
  const q = room.deck[room.qIndex] && QBY[room.deck[room.qIndex]];
  const v = {
    code: room.code, phase: room.phase, you: me.id, hostId: room.hostId, isHost: host, settings: room.settings, now: now(),
    pool: { ecg: POOL.ecg.length, xray: POOL.xray.length }, games: room.games,
    players: room.players.map(p => ({ id: p.id, name: p.name, connected: isConn(room.code, p.id), isHost: p.id === room.hostId, plays: p.plays, score: p.score, total: p.total, wins: p.wins,
      status: room.phase === 'question' ? (!p.plays ? 'spectating' : p.answer ? 'submitted' : 'answering') : room.phase === 'judging' ? (!p.plays ? 'spectating' : p.answer ? (p.verdict === null ? 'pending' : 'judged') : 'noanswer') : '' })),
  };
  if (['question', 'judging', 'reveal'].includes(room.phase) && q) {
    v.q = { n: room.qIndex + 1, of: room.deck.length, type: q.type, img: q.img };
    v.deadline = room.deadline; v.revealUntil = room.revealUntil;
    v.myAnswer = me.answer; v.plays = me.plays;
  }
  if (room.phase === 'judging' && host) {
    v.judge = { ref: q.dx, verified: q.verified, items: active(room).map(p => ({ id: p.id, name: p.name, answer: p.answer, verdict: p.verdict })) };
  }
  if (room.phase === 'reveal') {
    const h = room.history[room.history.length - 1];
    v.reveal = { dx: q.dx, verified: q.verified, items: active(room).map(p => ({ id: p.id, name: p.name, answer: h.res[p.id] ? h.res[p.id].answer : null, ok: h.res[p.id] ? h.res[p.id].ok : false, score: p.score })) };
    v.board = rank(room);
  }
  if (room.phase === 'final') {
    v.board = rank(room);
    v.review = room.history.map((h, i) => { const qq = QBY[h.id]; return { n: i + 1, img: qq.img, type: qq.type, dx: qq.dx, verified: qq.verified, mine: h.res[me.id] ? { answer: h.res[me.id].answer, ok: h.res[me.id].ok } : null }; });
  }
  return v;
}
function sendTo(c, room) {
  const p = getP(room, c.pid); if (!p) return;
  try { c.res.write('event: state\ndata: ' + JSON.stringify(view(room, p)) + '\n\n'); } catch (_) { /* closed */ }
}
function broadcast(room) { const s = conns.get(room.code); if (s) s.forEach(c => sendTo(c, room)); }

/* ---------- actions ---------- */
function act(room, p, a) {
  const host = p.id === room.hostId;
  const needHost = () => { if (!host) throw err(403, 'Host only'); };
  switch (a.type) {
    case 'settings': {
      needHost(); if (room.phase !== 'lobby') throw err(409, 'Game already started');
      const s = room.settings;
      if (a.count != null) s.count = Math.max(1, Math.min(60, parseInt(a.count, 10) || 10));
      if (a.category != null && ['mix', 'ecg', 'xray'].includes(a.category)) s.category = a.category;
      if (a.timer != null && [0, 30, 45, 60, 90, 120, 180].includes(+a.timer)) s.timer = +a.timer;
      if (a.hostPlays != null) { s.hostPlays = !!a.hostPlays; p.plays = s.hostPlays; }
      break;
    }
    case 'start': {
      needHost(); if (room.phase !== 'lobby') throw err(409, 'Already started');
      startGame(room); return;
    }
    case 'submit': {
      if (room.phase !== 'question') throw err(409, 'Not accepting answers');
      if (!p.plays) throw err(403, 'You are spectating');
      if (p.answer) throw err(409, 'Already submitted');
      const t = clean(a.answer, MAX_ANSWER); if (!t) throw err(400, 'Type a diagnosis first');
      p.answer = t; touch(room); broadcast(room); checkAllIn(room); return;
    }
    case 'endQuestion': needHost(); if (room.phase !== 'question') throw err(409, 'Not in question'); toJudging(room); return;
    case 'judge': {
      needHost(); if (room.phase !== 'judging') throw err(409, 'Not judging');
      const t = getP(room, a.target); if (!t || !t.plays || !t.answer) throw err(400, 'Nothing to judge');
      if (a.correct !== true && a.correct !== false && a.correct !== null) throw err(400, 'Bad verdict');
      t.verdict = a.correct; touch(room);
      break;
    }
    case 'finalize': {
      needHost(); if (room.phase !== 'judging') throw err(409, 'Not judging');
      if (pendingJudge(room).length) throw err(409, 'Judge every answer first');
      finalize(room); return;
    }
    case 'next': needHost(); if (room.phase !== 'reveal') throw err(409, 'Not in reveal'); nextQuestion(room); return;
    case 'endGame': needHost(); if (!['question', 'judging', 'reveal'].includes(room.phase)) throw err(409, 'No game running'); endGame(room); return;
    case 'playAgain': needHost(); if (room.phase !== 'final') throw err(409, 'Game not finished'); startGame(room); return;
    case 'toLobby': needHost(); if (room.phase !== 'final') throw err(409, 'Game not finished'); toLobby(room); return;
    case 'makeHost': {
      needHost(); const t = getP(room, a.target); if (!t) throw err(400, 'No such player');
      transferHost(room, t); return;
    }
    case 'kick': {
      needHost(); const t = getP(room, a.target); if (!t || t.id === p.id) throw err(400, 'Cannot remove');
      removePlayer(room, t, 'kicked'); return;
    }
    case 'leave': { removePlayer(room, p, 'left'); return; }
    default: throw err(400, 'Unknown action');
  }
  touch(room); broadcast(room);
}
function transferHost(room, t) {
  const old = getP(room, room.hostId);
  room.hostId = t.id;
  if (room.phase === 'lobby') { t.plays = true; if (old) old.plays = true; }
  touch(room); broadcast(room);
}
function removePlayer(room, t, why) {
  const s = conns.get(room.code);
  if (s) [...s].filter(c => c.pid === t.id).forEach(c => { try { c.res.write(`event: gone\ndata: ${JSON.stringify({ why })}\n\n`); c.res.end(); } catch (_) {} s.delete(c); });
  room.players = room.players.filter(x => x.id !== t.id);
  if (!room.players.length) { rooms.delete(room.code); clearTimeout(timers.get(room.code)); save(); return; }
  if (room.hostId === t.id) { const nh = room.players.find(x => isConn(room.code, x.id)) || room.players[0]; room.hostId = nh.id; if (room.phase === 'lobby') nh.plays = true; }
  touch(room); broadcast(room); checkAllIn(room);
}
const err = (code, msg) => Object.assign(new Error(msg), { code });

/* ---------- housekeeping ---------- */
setInterval(() => {
  const t = now();
  for (const room of [...rooms.values()]) {
    const host = getP(room, room.hostId);
    if (host && !isConn(room.code, host.id) && t - host.lastSeen > HOST_GRACE_MS) {
      const nh = room.players.filter(p => p.id !== host.id && isConn(room.code, p.id)).sort((a, b) => a.joined - b.joined)[0];
      if (nh) { transferHost(room, nh); }
    }
    if (room.phase === 'lobby') room.players.filter(p => !isConn(room.code, p.id) && t - p.lastSeen > 10 * 60000).forEach(p => removePlayer(room, p, 'timeout'));
    if (t - room.updated > ROOM_TTL_MS && !(conns.get(room.code) || { size: 0 }).size) { rooms.delete(room.code); clearTimeout(timers.get(room.code)); save(); }
  }
}, 5000);
setInterval(() => conns.forEach(s => s.forEach(c => { try { c.res.write(': hb\n\n'); } catch (_) {} })), 20000);

/* ---------- HTTP ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
function json(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
function body(req) {
  return new Promise((ok, no) => { let b = ''; req.on('data', d => { b += d; if (b.length > 8192) { no(err(413, 'Too large')); req.destroy(); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (_) { no(err(400, 'Bad JSON')); } }); });
}
function auth(code, pid, token) {
  const room = rooms.get(String(code || '').toUpperCase());
  if (!room) throw err(404, 'Room not found');
  const p = getP(room, pid);
  if (!p || typeof token !== 'string' || token.length !== p.token.length || !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(p.token))) throw err(401, 'Not authorised');
  return { room, p };
}
const joinOK = (room, p) => ({ code: room.code, pid: p.id, token: p.token });

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x');
    const p = u.pathname;
    if (p === '/healthz') return json(res, 200, { ok: true, rooms: rooms.size, questions: QUESTIONS.length });
    if (p === '/api/meta') return json(res, 200, { ecg: POOL.ecg.length, xray: POOL.xray.length });

    if (p === '/api/create' && req.method === 'POST') {
      const b = await body(req); const name = clean(b.name, MAX_NAME); if (!name) throw err(400, 'Enter your name');
      if (rooms.size >= MAX_ROOMS) throw err(503, 'Server is full, try later');
      const { room, player } = createRoom(name); return json(res, 200, joinOK(room, player));
    }
    if (p === '/api/join' && req.method === 'POST') {
      const b = await body(req); const room = rooms.get(String(b.code || '').toUpperCase().trim());
      if (!room) throw err(404, 'Room not found – check the code');
      if (b.pid && b.token) { // reconnect
        try { const a = auth(room.code, b.pid, b.token); return json(res, 200, joinOK(a.room, a.p)); } catch (_) { /* fall through to new join */ }
      }
      const name = clean(b.name, MAX_NAME); if (!name) throw err(400, 'Enter your name');
      if (room.players.length >= MAX_PLAYERS) throw err(409, 'Room is full');
      const dup = room.players.find(x => x.name.toLowerCase() === name.toLowerCase());
      if (dup) { // same name: only allowed to take over an OFFLINE seat (lost device / cleared storage)
        if (isConn(room.code, dup.id) || now() - dup.lastSeen < 20000) throw err(409, 'That name is already in use in this room');
        dup.token = rid(16); dup.lastSeen = now(); touch(room); return json(res, 200, joinOK(room, dup));
      }
      const np = mkPlayer(name); np.plays = true; room.players.push(np); touch(room); broadcast(room);
      return json(res, 200, joinOK(room, np));
    }
    if (p === '/api/stream') {
      const { room, p: me } = auth(u.searchParams.get('code'), u.searchParams.get('pid'), u.searchParams.get('token'));
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.write('retry: 1500\n\n');
      const c = { res, pid: me.id };
      if (!conns.has(room.code)) conns.set(room.code, new Set());
      conns.get(room.code).add(c); me.connected = true; me.lastSeen = now();
      sendTo(c, room); broadcast(room);
      req.on('close', () => {
        const s = conns.get(room.code); if (s) s.delete(c);
        me.lastSeen = now();
        if (rooms.has(room.code)) { broadcast(room); checkAllIn(room); }
      });
      return;
    }
    if (p === '/api/action' && req.method === 'POST') {
      const b = await body(req); const { room, p: me } = auth(b.code, b.pid, b.token);
      me.lastSeen = now(); act(room, me, b); return json(res, 200, { ok: true });
    }
    // ---- static files ----
    let f = p === '/' || /^\/r\/[A-Za-z]{4}\/?$/.test(p) ? '/index.html' : decodeURIComponent(p);
    const full = path.normalize(path.join(PUBLIC, f));
    if (!full.startsWith(PUBLIC + path.sep) && full !== PUBLIC) { res.writeHead(403); return res.end(); }
    fs.stat(full, (e, st) => {
      if (e || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
      const ext = path.extname(full).toLowerCase();
      const etag = '"' + st.size + '-' + st.mtimeMs.toString(36) + '"';
      if (req.headers['if-none-match'] === etag) { res.writeHead(304); return res.end(); }
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size, ETag: etag, 'Cache-Control': ext === '.jpg' ? 'public, max-age=604800' : 'no-cache' });
      fs.createReadStream(full).pipe(res);
    });
  } catch (e) {
    if (!e.code || typeof e.code !== 'number') { console.error(e); return json(res, 500, { error: 'Server error' }); }
    json(res, e.code, { error: e.message });
  }
});

load();
server.listen(PORT, () => console.log(`Quiz server on :${PORT} – ${POOL.ecg.length} ECG + ${POOL.xray.length} X-ray questions`));
process.on('SIGTERM', () => { try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(path.join(DATA_DIR, 'rooms.json'), JSON.stringify([...rooms.values()])); } catch (_) {} process.exit(0); });
